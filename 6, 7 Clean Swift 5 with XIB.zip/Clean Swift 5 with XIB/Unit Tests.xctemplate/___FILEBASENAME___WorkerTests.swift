//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

@testable import ___PROJECTNAMEASIDENTIFIER___
import XCTest

class ___VARIABLE_sceneName___ServiceTests: XCTestCase {
  // MARK: Subject under test
  
  var sut: ___VARIABLE_sceneName___Service!
  
  // MARK: Test lifecycle
  
  override func setUp() {
    super.setUp()
    setup___VARIABLE_sceneName___Service()
  }
  
  override func tearDown() {
    super.tearDown()
  }
  
  // MARK: Test setup
  
  func setup___VARIABLE_sceneName___Service() {
    sut = ___VARIABLE_sceneName___Service()
  }
  
  // MARK: Test doubles
  
  // MARK: Tests
  
  func testModel() {
    // Given
    
    // When
    
    // Then
  }
  
}
